This is a simulation of 4 kinds of cpu scheduling: fifo, lifo, round robin, highest penalty ratio next.



How to run:

1/ open terminal
	
2/enter:
		javac Main.java Process.java

		
		
3/enter:
		java Main input_1

			OR

		java Main input_1 --verbose 
			

		------------ "input_1" can be anything : your test file name
		------------ verbose means showing detailed step, easy for debugging